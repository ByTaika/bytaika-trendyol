=== KRN - Trendyol Entegrasyonu ===
Contributors: krn_digital
Tags: woocommerce, trendyol, entegrasyon
Requires at least: 5.8
Tested up to: 6.5
Stable tag: 1.0.1

== Description ==
Trendyol ürünlerini WooCommerce mağazanıza entegre eder.

== Changelog ==
= 1.0.1 =
* Otomatik stok güncelleme özelliği eklendi
* Ayarlar sayfasında saat seçimi ve API testi geldi
* CSV dışa aktarma eklendi
